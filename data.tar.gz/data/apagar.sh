#!/bin�/sh
echo -n "Apagando el servicio"

exit 0
