#!/bin/sh
echo -n "Encendiendo el servicio"
while :
do	
	echo "Uff" >> miDemonio.log
done
exit 0
